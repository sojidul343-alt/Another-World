# Another World 1.1.0 source changes

This is a fork/customized build of Square. Original copyright and license notices are retained.

Changes in this patch:
- App wordmark now reads ANOTHER WORLD.
- About/version footer now identifies the app as Another World.
- App versionName bumped to 1.1.0.
- YouTube Music search failures are logged and propagated to the existing Search error UI instead of being silently converted to empty results.
- The signed-in YouTube Music library adds a fallback Liked Songs entry if the account playlist shelf omits its synthetic Liked Music row.

Important limitations:
- The YouTube Music HTTP 400 / DNS errors from the diagnostic report are not proven fixed by these changes. They need a fresh on-device report and network test.
- Liked Songs requires a signed-in YouTube Music account and a functioning library endpoint.
- This source patch could not be compiled in this environment because Gradle distribution download was blocked by DNS/network access. Run the repository's GitHub Actions build before installing.
