# Another World — Android music player

A personal fork of [Square](https://github.com/Lelonio/Square) 2.10.3. The original GPL-3.0 license and third-party notices are retained.

## Current fork changes

- Android display name: **Another World**
- Android application ID: `com.anotherworld.music`
- Version name: `1.0.0`
- Updater repository changed to `YOUR_GITHUB_USERNAME/Another-World` so this fork does not offer the upstream Square releases. Set it to your own GitHub repository before publishing releases.
- Original Kotlin namespace is intentionally retained as `dev.lelonio.square` to avoid breaking the existing source tree and generated resource references.

## Features inherited from the upstream project

- Liquid Glass interface
- Synchronized lyrics
- Speed, pitch and reverb effects (including Slowed + Reverb presets)
- Crossfade and sleep timer
- Local music library and offline downloads
- YouTube Music backend
- Spotify backend (requires Spotify Premium and a developer app/client ID)

These are inherited capabilities, not yet independently tested in this fork. YouTube Music relies on undocumented/private endpoints and may break when the service changes. Spotify integration is unofficial and is not endorsed by Spotify.

## Build requirements

See [`docs/DEVELOPMENT.md`](docs/DEVELOPMENT.md). The upstream build requires Android SDK platform 37, Android NDK `28.2.13676358`, Rust 1.86 or later, Android Rust targets, and `cargo-ndk`. Build with:

```bash
./gradlew :app:assembleDebug
```

The project includes native Rust code, so it cannot be built as a simple HTML/JavaScript app in Acode alone. A Linux/macOS/Windows development environment or a properly configured GitHub Actions runner is required.

## License and attribution

This fork is based on Square, Copyright its original authors and contributors. It is distributed under **GNU GPL v3**; see [`LICENSE`](LICENSE). Preserve the license, copyright notices, and corresponding source when distributing modified binaries. Review the licenses/notices for bundled components before redistribution.
